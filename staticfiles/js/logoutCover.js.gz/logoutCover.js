function logoutDisplayOn() {
	var ldc = document.getElementById("ldc_logout");
	if(ldc) {
		ldc.style.display = "block"
	}
}

function logoutDisplayOff() {
	var ldc = document.getElementById("ldc_logout");
	if(ldc) {
		ldc.style.display = "none"
	}
}